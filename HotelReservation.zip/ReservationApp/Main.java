import Guest.GuestController;
import Guest.GuestModel;
import Guest.GuestView;

public class Main {

    public static void main(String[] args) {

        GuestView gView = new GuestView();
        GuestModel gModel = new GuestModel();
        new GuestController(gView, gModel);
        gView.setVisible(true);

    }
}