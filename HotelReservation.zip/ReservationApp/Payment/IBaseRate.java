package Payment;

public interface IBaseRate {
    default double getBaseRate(){
        return 60.50;
    }
}
