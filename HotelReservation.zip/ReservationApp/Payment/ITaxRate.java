package Payment;

public interface ITaxRate {
    default double getTaxRate(){
        return 0.04;
    }
}
