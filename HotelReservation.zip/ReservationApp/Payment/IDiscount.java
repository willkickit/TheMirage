package Payment;

public interface IDiscount {
    default double discountRate(){
        return 0.15;
    }
}
